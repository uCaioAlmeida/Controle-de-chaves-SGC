import React, { useState, useEffect } from 'react';
import { KeyTransaction, TransactionStatus } from './types';
import * as DataService from './services/dataService';
import * as GeminiService from './services/geminiService';
import * as XLSX from 'xlsx';
import { isConfigured } from './services/firebaseConfig'; 
import { TransactionList } from './components/TransactionList';
import { KeyCheckoutForm } from './components/KeyCheckoutForm';
import { ReservationImportModal } from './components/ReservationImportModal';
import { FirebaseSetupGuide } from './components/FirebaseSetupGuide';

import { 
  LayoutDashboard, 
  History, 
  Sparkles, 
  Key, 
  LogOut, 
  Search,
  PlusCircle,
  X,
  ShieldCheck,
  FileSpreadsheet,
  Download,
  Share2,
  Check
} from 'lucide-react';

const App: React.FC = () => {
  
  // Se não houver configuração do Firebase, exibe o guia
  if (!isConfigured) {
    return <FirebaseSetupGuide />;
  }
  
  const [transactions, setTransactions] = useState<KeyTransaction[]>([]);
  const [view, setView] = useState<'DASHBOARD' | 'HISTORY'>('DASHBOARD');
  const [showCheckoutModal, setShowCheckoutModal] = useState(false);
  const [showImportModal, setShowImportModal] = useState(false);
  const [aiReport, setAiReport] = useState<string | null>(null);
  const [isGeneratingReport, setIsGeneratingReport] = useState(false);
  const [searchTerm, setSearchTerm] = useState('');
  const [linkCopied, setLinkCopied] = useState(false);

  // Assinatura dos dados (agora via Firestore Realtime)
  useEffect(() => {
      const unsubscribe = DataService.subscribeToTransactions((data) => {
        setTransactions(data);
      });
      return () => unsubscribe();
  }, []);

  const handleCheckout = async (data: Omit<KeyTransaction, 'id' | 'status' | 'pickupTime' | 'returnTime'>) => {
    const newTransaction: KeyTransaction = {
      id: 'temp-id', // O DataService/Firestore vai gerar o ID real
      pickupTime: new Date().toISOString(),
      status: TransactionStatus.ACTIVE,
      ...data
    };
    await DataService.saveTransaction(newTransaction);
    setShowCheckoutModal(false);
  };

  const handleReturn = async (id: string) => {
    await DataService.updateTransaction(id, {
      returnTime: new Date().toISOString(),
      status: TransactionStatus.COMPLETED
    });
  };

  const handleGenerateReport = async () => {
    setIsGeneratingReport(true);
    setAiReport(null);
    const report = await GeminiService.generateDailyReport(transactions);
    setAiReport(report);
    setIsGeneratingReport(false);
  };

  const handleShareLink = () => {
    navigator.clipboard.writeText(window.location.href);
    setLinkCopied(true);
    setTimeout(() => setLinkCopied(false), 2000);
  };

  const handleExportExcel = () => {
    const now = new Date();
    const todayString = now.toLocaleDateString('pt-BR'); // DD/MM/AAAA

    // Filtra transações onde a Retirada OU a Devolução aconteceram HOJE
    const dailyData = transactions.filter(t => {
      const pickupDate = new Date(t.pickupTime).toLocaleDateString('pt-BR');
      const returnDate = t.returnTime ? new Date(t.returnTime).toLocaleDateString('pt-BR') : null;
      
      return pickupDate === todayString || returnDate === todayString;
    }).map(t => ({
       "Status": t.status === TransactionStatus.ACTIVE ? 'Pendente' : 'Concluído',
       "Responsável": t.personName,
       "Laboratório": t.labName,
       "Chave": t.keyLetter,
       "Tipo Reserva": t.reservationType,
       "Retirada": new Date(t.pickupTime).toLocaleString('pt-BR'),
       "Devolução": t.returnTime ? new Date(t.returnTime).toLocaleString('pt-BR') : '-',
       "Extras": t.additionalItems.join(', '),
       "Agendado Até": t.scheduledEndTime || '-'
    }));

    if (dailyData.length === 0) {
      alert("Nenhuma movimentação registrada na data de hoje (" + todayString + ").");
      return;
    }

    // Cria a planilha
    const worksheet = XLSX.utils.json_to_sheet(dailyData);
    const workbook = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(workbook, worksheet, "Relatório Diário");

    // Ajusta largura das colunas (estético)
    const wscols = [
      {wch: 10}, // Status
      {wch: 25}, // Responsável
      {wch: 30}, // Lab
      {wch: 8},  // Chave
      {wch: 20}, // Tipo
      {wch: 18}, // Retirada
      {wch: 18}, // Devolução
      {wch: 20}, // Extras
      {wch: 10}  // Agendado
    ];
    worksheet['!cols'] = wscols;

    // Download
    const fileName = `SGC_Relatorio_${todayString.replace(/\//g, '-')}.xlsx`;
    XLSX.writeFile(workbook, fileName);
  };

  const activeCount = transactions.filter(t => t.status === TransactionStatus.ACTIVE).length;
  const todayCount = transactions.filter(t => {
    const date = new Date(t.pickupTime);
    const today = new Date();
    return date.getDate() === today.getDate() && 
           date.getMonth() === today.getMonth() && 
           date.getFullYear() === today.getFullYear();
  }).length;

  const filteredTransactions = transactions.filter(t => 
    t.personName.toLowerCase().includes(searchTerm.toLowerCase()) ||
    t.labName.toLowerCase().includes(searchTerm.toLowerCase())
  );

  return (
    <div className="min-h-screen bg-gray-50 flex flex-col md:flex-row font-sans text-gray-800">
      
      {/* Sidebar Navigation */}
      <aside className="w-full md:w-64 bg-white border-r border-gray-200 flex flex-col sticky top-0 md:h-screen z-10">
        <div className="p-6 border-b border-gray-100 flex items-center gap-3">
          <div className="bg-blue-600 p-2 rounded-lg">
            <ShieldCheck className="w-6 h-6 text-white" />
          </div>
          <div className="flex flex-col">
            <span className="text-lg font-bold text-gray-800 leading-none">SGC</span>
            <span className="text-xs text-blue-600 font-semibold tracking-wider">SENAI CIMATEC</span>
          </div>
        </div>

        <nav className="flex-1 p-4 space-y-2">
          <button
            onClick={() => setView('DASHBOARD')}
            className={`w-full flex items-center gap-3 px-4 py-3 rounded-xl transition-all font-medium ${
              view === 'DASHBOARD' 
                ? 'bg-blue-50 text-blue-700 shadow-sm' 
                : 'text-gray-600 hover:bg-gray-100'
            }`}
          >
            <LayoutDashboard className="w-5 h-5" />
            Painel Principal
          </button>

          <button
            onClick={() => setView('HISTORY')}
            className={`w-full flex items-center gap-3 px-4 py-3 rounded-xl transition-all font-medium ${
              view === 'HISTORY' 
                ? 'bg-blue-50 text-blue-700 shadow-sm' 
                : 'text-gray-600 hover:bg-gray-100'
            }`}
          >
            <History className="w-5 h-5" />
            Histórico Completo
          </button>

          <button
            onClick={() => setShowImportModal(true)}
            className="w-full flex items-center gap-3 px-4 py-3 rounded-xl transition-all font-medium text-gray-600 hover:bg-green-50 hover:text-green-700"
          >
            <FileSpreadsheet className="w-5 h-5" />
            Importar Reservas
          </button>
        </nav>

        <div className="p-4 border-t border-gray-100 bg-gray-50/50">
           <div className="text-xs text-gray-400 font-medium uppercase tracking-wider mb-2">Resumo do Dia</div>
           <div className="flex justify-between items-center mb-1">
             <span className="text-sm text-gray-600">Pendentes</span>
             <span className="font-bold text-blue-600 bg-blue-100 px-2 py-0.5 rounded-full text-xs">{activeCount}</span>
           </div>
           <div className="flex justify-between items-center">
             <span className="text-sm text-gray-600">Total Hoje</span>
             <span className="font-bold text-gray-700">{todayCount}</span>
           </div>
        </div>
      </aside>

      {/* Main Content */}
      <main className="flex-1 p-4 md:p-8 overflow-y-auto">
        
        {/* Header */}
        <header className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4 mb-8">
          <div>
            <h1 className="text-2xl font-bold text-gray-900">
              {view === 'DASHBOARD' ? 'Controle de Chaves' : 'Histórico SGC'}
            </h1>
            <p className="text-gray-500 text-sm">
              Registro de entrega e devolução de chaves (Online).
            </p>
          </div>

          <div className="flex flex-wrap items-center gap-3 w-full md:w-auto">
             <button
              onClick={handleShareLink}
              className={`flex items-center gap-2 px-3 py-2 border rounded-lg transition-all text-sm font-medium ${linkCopied ? 'bg-green-50 text-green-700 border-green-200' : 'bg-white text-gray-600 border-gray-200 hover:bg-gray-50'}`}
              title="Copiar Link"
             >
               {linkCopied ? <Check className="w-4 h-4" /> : <Share2 className="w-4 h-4" />}
               {linkCopied ? 'Copiado!' : 'Compartilhar'}
             </button>

             <button
              onClick={handleExportExcel}
              className="flex items-center gap-2 px-4 py-2 bg-emerald-50 text-emerald-700 border border-emerald-200 rounded-lg hover:bg-emerald-100 transition-colors text-sm font-medium"
              title="Baixar planilha do dia"
             >
               <Download className="w-4 h-4" />
               Excel do Dia
             </button>

             <button
              onClick={() => handleGenerateReport()}
              disabled={isGeneratingReport}
              className="hidden md:flex items-center gap-2 px-4 py-2 bg-indigo-50 text-indigo-700 border border-indigo-200 rounded-lg hover:bg-indigo-100 transition-colors text-sm font-medium"
            >
              <Sparkles className={`w-4 h-4 ${isGeneratingReport ? 'animate-pulse' : ''}`} />
              {isGeneratingReport ? 'Processando IA...' : 'Relatório IA'}
            </button>
            <button 
              onClick={() => setShowCheckoutModal(true)}
              className="flex-1 md:flex-none flex items-center justify-center gap-2 px-5 py-2.5 bg-blue-600 text-white rounded-lg hover:bg-blue-700 shadow-lg shadow-blue-200 transition-all font-medium active:scale-95"
            >
              <PlusCircle className="w-5 h-5" />
              Nova Retirada
            </button>
          </div>
        </header>

        {/* AI Report Section */}
        {aiReport && (
          <div className="mb-8 bg-white p-6 rounded-2xl border border-indigo-100 shadow-sm relative animate-fade-in ring-1 ring-indigo-50">
            <button 
              onClick={() => setAiReport(null)}
              className="absolute top-4 right-4 p-1 hover:bg-gray-100 rounded-full transition-colors text-gray-400"
            >
              <X className="w-5 h-5" />
            </button>
            <div className="flex items-center gap-2 mb-4 text-indigo-800">
              <Sparkles className="w-5 h-5" />
              <h3 className="font-bold text-lg">Análise SGC</h3>
            </div>
            <div className="prose prose-indigo prose-sm max-w-none text-gray-600 leading-relaxed whitespace-pre-line">
              {aiReport}
            </div>
          </div>
        )}

        {/* Quick Stats Grid */}
        {view === 'DASHBOARD' && (
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
            <div className="bg-white p-5 rounded-xl border border-gray-100 shadow-sm flex items-center gap-4">
              <div className="p-3 bg-blue-100 text-blue-600 rounded-full">
                <Key className="w-6 h-6" />
              </div>
              <div>
                <p className="text-sm text-gray-500 font-medium">Chaves Pendentes</p>
                <p className="text-2xl font-bold text-gray-900">{activeCount}</p>
              </div>
            </div>

            <div className="bg-white p-5 rounded-xl border border-gray-100 shadow-sm flex items-center gap-4">
              <div className="p-3 bg-emerald-100 text-emerald-600 rounded-full">
                <LogOut className="w-6 h-6" />
              </div>
              <div>
                <p className="text-sm text-gray-500 font-medium">Movimentações</p>
                <p className="text-2xl font-bold text-gray-900">{todayCount}</p>
              </div>
            </div>

            <div className="bg-white p-5 rounded-xl border border-gray-100 shadow-sm flex items-center gap-4 cursor-pointer hover:border-indigo-200 transition-colors" onClick={handleGenerateReport}>
              <div className="p-3 bg-indigo-100 text-indigo-600 rounded-full">
                <Sparkles className="w-6 h-6" />
              </div>
              <div>
                <p className="text-sm text-gray-500 font-medium">Assistente IA</p>
                <p className="text-xs text-indigo-600 font-semibold mt-1">
                  {isGeneratingReport ? 'Gerando...' : 'Gerar análise'}
                </p>
              </div>
            </div>
          </div>
        )}

        {/* Search Bar */}
        <div className="mb-6 relative">
          <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
          <input 
            type="text" 
            placeholder="Pesquisar por responsável ou laboratório..." 
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="w-full pl-12 pr-4 py-3 bg-white border border-gray-200 rounded-xl focus:ring-2 focus:ring-blue-100 focus:border-blue-400 transition-all outline-none text-gray-700 shadow-sm"
          />
        </div>

        {/* Lists */}
        <div className="bg-transparent rounded-xl">
          {view === 'DASHBOARD' ? (
            <div>
              <div className="flex items-center gap-2 mb-4">
                <div className="w-2 h-6 bg-amber-400 rounded-full"></div>
                <h3 className="text-lg font-semibold text-gray-800">Em Aberto (Retiradas)</h3>
              </div>
              <TransactionList 
                transactions={filteredTransactions} 
                onReturn={handleReturn} 
                filter="ACTIVE" 
              />
            </div>
          ) : (
             <div>
              <div className="flex items-center gap-2 mb-4">
                <div className="w-2 h-6 bg-gray-600 rounded-full"></div>
                <h3 className="text-lg font-semibold text-gray-800">Histórico de Registros</h3>
              </div>
              <TransactionList 
                transactions={filteredTransactions} 
                onReturn={handleReturn} 
                filter="ALL" 
              />
            </div>
          )}
        </div>
      </main>

      {/* Modal Overlay: Checkout */}
      {showCheckoutModal && (
        <div className="fixed inset-0 bg-black/40 backdrop-blur-sm z-50 flex items-center justify-center p-4 animate-fade-in">
          <div className="w-full max-w-lg animate-scale-in">
            <KeyCheckoutForm 
              onSubmit={handleCheckout} 
              onCancel={() => setShowCheckoutModal(false)} 
            />
          </div>
        </div>
      )}

      {/* Modal Overlay: Excel Import */}
      {showImportModal && (
        <div className="fixed inset-0 bg-black/40 backdrop-blur-sm z-50 flex items-center justify-center p-4 animate-fade-in">
          <div className="w-full max-w-2xl animate-scale-in flex justify-center">
            <ReservationImportModal 
              onClose={() => setShowImportModal(false)}
              onSuccess={() => {/* Maybe show a toast */}}
            />
          </div>
        </div>
      )}
      
      {/* Mobile Report Button */}
      <button
        onClick={handleGenerateReport}
        className="md:hidden fixed bottom-6 left-6 p-4 bg-indigo-600 text-white rounded-full shadow-lg shadow-indigo-300 z-40 active:scale-90 transition-transform"
        aria-label="Gerar Relatório"
      >
        <Sparkles className="w-6 h-6" />
      </button>

      <style>{`
        @keyframes fade-in {
          from { opacity: 0; }
          to { opacity: 1; }
        }
        @keyframes scale-in {
          from { transform: scale(0.95); opacity: 0; }
          to { transform: scale(1); opacity: 1; }
        }
        .animate-fade-in {
          animation: fade-in 0.2s ease-out;
        }
        .animate-scale-in {
          animation: scale-in 0.2s ease-out;
        }
      `}</style>
    </div>
  );
};

export default App;