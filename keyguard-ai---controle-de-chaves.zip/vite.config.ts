// Configuração desativada para permitir a visualização direta no navegador
// sem necessidade de build ou instalação de dependências locais.
export default {};