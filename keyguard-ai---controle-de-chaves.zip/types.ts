export enum TransactionStatus {
  ACTIVE = 'ACTIVE',
  COMPLETED = 'COMPLETED'
}

export type KeyLetter = 'A' | 'B' | 'C' | 'D' | 'E' | 'F' | 'Lab' | 'Lab RESERVA';
export type ReservationType = 'Reserva programada' | 'Reserva extra / emergencial';

export interface KeyTransaction {
  id: string;
  personName: string; // 1. Responsável
  labName: string; // 2. Sala / Laboratório
  keyLetter: KeyLetter; // 3. Qual letra da chave?
  reservationType: ReservationType; // 4. Tipo de reserva
  additionalItems: string[]; // 5. Extras (Piloto, Apagador...)
  pickupTime: string;
  returnTime?: string;
  scheduledEndTime?: string; // NOVO: Horário limite previsto (HH:mm) baseado na planilha
  status: TransactionStatus;
}

export interface Reservation {
  id: string;
  labName: string;
  responsible: string;
  date: string; // YYYY-MM-DD
  startTime: string; // HH:mm
  endTime: string; // HH:mm
}

export interface DailyStats {
  totalActive: number;
  totalToday: number;
  frequentKey: string;
}