import React, { useState, useRef, useMemo } from 'react';
import { Reservation } from '../types';
import { Save, X, FileSpreadsheet, AlertCircle, UploadCloud, FileText, Loader2, Trash2, CalendarCheck } from 'lucide-react';
import * as DataService from '../services/dataService';
import * as XLSX from 'xlsx';

interface ReservationImportModalProps {
  onClose: () => void;
  onSuccess: () => void;
}

export const ReservationImportModal: React.FC<ReservationImportModalProps> = ({ onClose, onSuccess }) => {
  const [textData, setTextData] = useState('');
  const [preview, setPreview] = useState<Reservation[]>([]);
  const [step, setStep] = useState<'INPUT' | 'PREVIEW'>('INPUT');
  const [isDragging, setIsDragging] = useState(false);
  const [isSaving, setIsSaving] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);

  // --- Helpers de Parsing do Excel ---

  // Converte Serial do Excel para String YYYY-MM-DD usando UTC puro para evitar shift de fuso
  const formatExcelSerialDate = (serial: number): string => {
    const utc_days  = Math.floor(serial - 25569);
    const utc_value = utc_days * 86400 * 1000;                                        
    const date = new Date(utc_value);
    
    // Extrai componentes UTC para garantir que a data visual do Excel seja mantida
    const year = date.getUTCFullYear();
    const month = String(date.getUTCMonth() + 1).padStart(2, '0');
    const day = String(date.getUTCDate()).padStart(2, '0');
    
    return `${year}-${month}-${day}`;
  };

  const toLocalISOString = (date: Date) => {
    const year = date.getFullYear();
    const month = String(date.getMonth() + 1).padStart(2, '0');
    const day = String(date.getDate()).padStart(2, '0');
    return `${year}-${month}-${day}`;
  };

  const formatExcelDate = (val: any): string => {
    if (!val) return toLocalISOString(new Date());
    
    // Se for número (serial do Excel)
    if (typeof val === 'number') {
      return formatExcelSerialDate(val);
    }
    
    // Se for string
    const str = val.toString().trim();
    // Tenta formatos comuns PT-BR
    if (str.includes('/')) {
      const parts = str.split('/'); 
      if (parts.length === 3) {
         // Se ano for 2 digitos (ex: 24), assume 2024
         let year = parts[2];
         if (year.length === 2) year = '20' + year;
         return `${year}-${parts[1].padStart(2, '0')}-${parts[0].padStart(2, '0')}`;
      }
    }
    // Formato YYYY-MM-DD direto
    if (str.includes('-')) {
        return str.split('T')[0];
    }
    
    return str;
  };

  const formatExcelTime = (val: any): string => {
    if (val === undefined || val === null) return '00:00';

    // Se for número (fração de dia, ex: 0.5 = 12:00)
    if (typeof val === 'number') {
      const totalSeconds = Math.round(val * 86400);
      const hours = Math.floor(totalSeconds / 3600) % 24;
      const minutes = Math.floor((totalSeconds % 3600) / 60);
      return `${String(hours).padStart(2, '0')}:${String(minutes).padStart(2, '0')}`;
    }

    // Se for string
    const str = val.toString().trim();
    const match = str.match(/(\d{1,2})[:h](\d{2})/);
    if (match) {
      return `${match[1].padStart(2, '0')}:${match[2]}`;
    }
    return '00:00';
  };

  const processExcelFile = async (file: File) => {
    try {
      const data = await file.arrayBuffer();
      // cellDates: false para tratar manualmente o serial number
      const workbook = XLSX.read(data, { cellDates: false }); 
      const firstSheetName = workbook.SheetNames[0];
      const worksheet = workbook.Sheets[firstSheetName];
      
      const jsonData = XLSX.utils.sheet_to_json(worksheet, { header: 1, defval: '' }) as any[][];

      if (jsonData.length < 2) {
        alert("O arquivo parece vazio ou sem dados.");
        return;
      }

      // Assume row 0 is header, start from row 1
      const dataRows = jsonData.slice(1);
      const parsed: Reservation[] = [];

      dataRows.forEach((row) => {
        // Validação: Pelo menos Nome da Sala (col 0) deve existir
        if (row && row.length > 0 && row[0]) {
           const labName = row[0]?.toString().trim() || 'Desconhecido';
           // Ignora cabeçalhos repetidos se houver
           if (labName.toLowerCase().includes('laboratório') && row[1]?.toString().toLowerCase().includes('responsável')) return;

           const responsible = row[1]?.toString().trim() || 'Desconhecido';
           const dateStr = formatExcelDate(row[2]);
           const startTime = formatExcelTime(row[3]);
           const endTime = formatExcelTime(row[4]);

           if (labName !== 'Desconhecido') {
             parsed.push({
              id: crypto.randomUUID(),
              labName,
              responsible,
              date: dateStr,
              startTime,
              endTime,
            });
           }
        }
      });

      setPreview(parsed);
      setStep('PREVIEW');
    } catch (error) {
      console.error(error);
      alert("Erro ao ler o arquivo Excel. Verifique se as colunas estão na ordem: Sala | Responsável | Data | Início | Fim");
    }
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(false);
    if (e.dataTransfer.files && e.dataTransfer.files.length > 0) {
      processExcelFile(e.dataTransfer.files[0]);
    }
  };

  const handlePaste = (e: React.ClipboardEvent) => {
    if (e.clipboardData.files && e.clipboardData.files.length > 0) {
        e.preventDefault();
        processExcelFile(e.clipboardData.files[0]);
    }
  };

  const handleFileSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files.length > 0) {
      processExcelFile(e.target.files[0]);
    }
  };

  const parseTextData = () => {
    const rows = textData.split(/\r\n|\n|\r/).filter(row => row.trim() !== '');
    const parsed: Reservation[] = [];

    rows.forEach((row) => {
      const cols = row.split('\t');
      if (cols.length >= 2) {
        let dateStr = cols[2] ? formatExcelDate(cols[2]) : toLocalISOString(new Date());
        parsed.push({
          id: crypto.randomUUID(),
          labName: cols[0]?.trim() || 'Desconhecido',
          responsible: cols[1]?.trim() || 'Desconhecido',
          date: dateStr,
          startTime: cols[3]?.trim() || '00:00',
          endTime: cols[4]?.trim() || '23:59',
        });
      }
    });

    setPreview(parsed);
    setStep('PREVIEW');
  };

  const handleSave = async () => {
    setIsSaving(true);
    await DataService.saveReservations(preview);
    setIsSaving(false);
    onSuccess();
    onClose();
  };

  const handleClear = async () => {
      if(confirm('Tem certeza? Isso apagará todas as reservas salvas no banco de dados.')) {
          setIsSaving(true);
          await DataService.clearReservations();
          setIsSaving(false);
          alert('Banco de dados de reservas limpo.');
      }
  }

  // Estatísticas do Preview
  const stats = useMemo(() => {
    const today = toLocalISOString(new Date());
    const countToday = preview.filter(p => p.date === today).length;
    return { total: preview.length, today: countToday, todayStr: today };
  }, [preview]);

  return (
    <div className="bg-white p-6 rounded-2xl shadow-xl border border-gray-100 w-full max-w-2xl max-h-[90vh] overflow-hidden flex flex-col">
      <div className="flex justify-between items-start mb-6">
        <div>
          <h2 className="text-xl font-bold text-gray-800 flex items-center gap-2">
            <FileSpreadsheet className="w-6 h-6 text-green-600" />
            Importar Reservas
          </h2>
          <p className="text-gray-500 text-sm mt-1">Envie o arquivo Excel ou cole os dados.</p>
        </div>
        <button onClick={onClose} className="p-1 hover:bg-gray-100 rounded-full transition-colors">
          <X className="w-5 h-5 text-gray-400" />
        </button>
      </div>

      {step === 'INPUT' ? (
        <div className="flex-1 flex flex-col gap-4 overflow-hidden">
          
          <div 
            onDragOver={(e) => { e.preventDefault(); setIsDragging(true); }}
            onDragLeave={() => setIsDragging(false)}
            onDrop={handleDrop}
            className={`border-2 border-dashed rounded-xl p-8 flex flex-col items-center justify-center text-center transition-colors cursor-pointer ${
              isDragging ? 'border-green-500 bg-green-50' : 'border-gray-300 hover:border-blue-400 hover:bg-gray-50'
            }`}
            onClick={() => fileInputRef.current?.click()}
          >
            <input 
              type="file" 
              ref={fileInputRef} 
              className="hidden" 
              accept=".xlsx,.xls" 
              onChange={handleFileSelect}
            />
            <div className="bg-green-100 p-3 rounded-full text-green-600 mb-3">
              <UploadCloud className="w-8 h-8" />
            </div>
            <p className="font-medium text-gray-700">Clique para selecionar ou arraste o arquivo Excel</p>
            <p className="text-sm text-gray-400 mt-1">Suporta .xlsx ou .xls</p>
          </div>

          <div className="relative flex py-2 items-center">
            <div className="flex-grow border-t border-gray-200"></div>
            <span className="flex-shrink-0 mx-4 text-gray-400 text-xs uppercase font-medium">Ou cole o texto</span>
            <div className="flex-grow border-t border-gray-200"></div>
          </div>
          
          <div className="relative flex-1 min-h-[150px]">
            <textarea
              value={textData}
              onChange={(e) => setTextData(e.target.value)}
              onPaste={handlePaste}
              placeholder="Cole aqui (Ctrl+V) as células copiadas do Excel..."
              className="absolute inset-0 w-full h-full p-4 border border-gray-300 rounded-xl focus:ring-2 focus:ring-blue-500 focus:border-blue-500 outline-none font-mono text-sm resize-none"
            />
          </div>

          <div className="bg-blue-50 border border-blue-100 p-3 rounded-lg text-xs text-blue-700 flex items-start gap-2">
            <AlertCircle className="w-4 h-4 mt-0.5 flex-shrink-0" />
            <div>
              <strong>Colunas esperadas:</strong> Sala | Responsável | Data | Início | Fim
            </div>
          </div>

          <div className="flex justify-between pt-2">
             <button
              onClick={handleClear}
              className="px-4 py-2.5 text-red-600 font-medium hover:bg-red-50 rounded-lg transition-colors flex items-center gap-2 text-xs"
            >
              <Trash2 className="w-3.5 h-3.5" />
              Limpar Banco de Dados
            </button>
            <button
              onClick={parseTextData}
              disabled={!textData.trim()}
              className="px-6 py-2.5 bg-blue-600 text-white font-medium rounded-lg hover:bg-blue-700 transition-colors disabled:opacity-50"
            >
              Processar Texto
            </button>
          </div>
        </div>
      ) : (
        <div className="flex-1 flex flex-col overflow-hidden">
          <div className="flex items-center justify-between mb-4 bg-gray-50 p-3 rounded-lg border border-gray-100">
            <div className="flex items-center gap-4">
               <span className="text-sm font-bold text-gray-700">{stats.total} registros</span>
               <div className="h-4 w-px bg-gray-300"></div>
               <div className="flex items-center gap-2 text-sm">
                  <CalendarCheck className="w-4 h-4 text-green-600" />
                  <span className={stats.today > 0 ? 'text-green-700 font-bold' : 'text-gray-500'}>
                    {stats.today} para Hoje ({stats.todayStr.split('-').reverse().join('/')})
                  </span>
               </div>
            </div>
            <button onClick={() => setStep('INPUT')} className="text-sm text-blue-600 hover:underline">
              Voltar
            </button>
          </div>

          <div className="flex-1 overflow-y-auto border border-gray-200 rounded-xl">
            <table className="w-full text-sm text-left">
              <thead className="bg-gray-50 text-gray-600 font-medium sticky top-0">
                <tr>
                  <th className="p-3 border-b">Laboratório</th>
                  <th className="p-3 border-b">Responsável</th>
                  <th className="p-3 border-b">Data</th>
                  <th className="p-3 border-b">Horário</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-gray-100">
                {preview.map((row) => (
                  <tr key={row.id} className={`hover:bg-gray-50 ${row.date === stats.todayStr ? 'bg-green-50/50' : ''}`}>
                    <td className="p-3 text-gray-900 font-medium">{row.labName}</td>
                    <td className="p-3 text-gray-600">{row.responsible}</td>
                    <td className="p-3 text-gray-500">{row.date}</td>
                    <td className="p-3 text-gray-500">{row.startTime} - {row.endTime}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>

          <div className="flex gap-3 pt-6 border-t border-gray-100 mt-4">
             <button onClick={onClose} disabled={isSaving} className="flex-1 px-4 py-2.5 border border-gray-300 text-gray-700 font-medium rounded-lg hover:bg-gray-50">
              Cancelar
            </button>
            <button
              onClick={handleSave}
              disabled={isSaving}
              className="flex-1 px-4 py-2.5 bg-green-600 text-white font-medium rounded-lg hover:bg-green-700 transition-colors flex items-center justify-center gap-2"
            >
              {isSaving ? <Loader2 className="w-4 h-4 animate-spin" /> : <Save className="w-4 h-4" />}
              Importar {preview.length} Reservas
            </button>
          </div>
        </div>
      )}
    </div>
  );
};