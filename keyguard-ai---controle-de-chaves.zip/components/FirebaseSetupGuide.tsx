import React from 'react';
import { Settings, MousePointerClick, Copy, Database, LayoutTemplate } from 'lucide-react';

export const FirebaseSetupGuide: React.FC = () => {
  return (
    <div className="min-h-screen bg-gray-50 flex items-center justify-center p-4 font-sans text-gray-800">
      <div className="max-w-3xl w-full bg-white rounded-2xl shadow-xl border border-gray-200 overflow-hidden">
        <div className="bg-blue-600 p-6 text-white">
          <h1 className="text-2xl font-bold flex items-center gap-3">
            <Database className="w-8 h-8" />
            Configuração do Banco de Dados
          </h1>
          <p className="mt-2 text-blue-100">
            Para que o SGC funcione online, precisamos conectar ao seu projeto Firebase. Siga os passos abaixo:
          </p>
        </div>

        <div className="p-8 space-y-8">
          
          {/* Step 1 */}
          <div className="flex gap-4">
            <div className="flex-shrink-0 w-8 h-8 bg-blue-100 text-blue-600 rounded-full flex items-center justify-center font-bold">1</div>
            <div className="space-y-2">
              <h3 className="font-bold text-lg">Acesse as Configurações do Projeto</h3>
              <p className="text-gray-600">
                No painel do Firebase (console.firebase.google.com), clique no ícone de <strong>Engrenagem</strong> ao lado de "Visão geral do projeto" e selecione <strong>Configurações do projeto</strong>.
              </p>
              <div className="bg-gray-100 p-3 rounded-lg border border-gray-200 flex items-center gap-2 text-sm text-gray-500">
                <Settings className="w-4 h-4" /> Menu Lateral &gt; Engrenagem &gt; Configurações do projeto
              </div>
            </div>
          </div>

          {/* Step 2 */}
          <div className="flex gap-4">
            <div className="flex-shrink-0 w-8 h-8 bg-blue-100 text-blue-600 rounded-full flex items-center justify-center font-bold">2</div>
            <div className="space-y-2">
              <h3 className="font-bold text-lg">Localize a seção "Seus aplicativos"</h3>
              <p className="text-gray-600">
                Role a página de configurações até o final. Você verá uma seção chamada <strong>Seus aplicativos</strong>.
              </p>
              <ul className="list-disc list-inside text-gray-600 text-sm ml-2 space-y-1">
                <li>Se não houver nenhum aplicativo listado, clique no ícone <strong>&lt;/&gt;</strong> (Web).</li>
                <li>Dê um apelido para o app (ex: "SGC Web") e clique em "Registrar app".</li>
              </ul>
            </div>
          </div>

          {/* Step 3 */}
          <div className="flex gap-4">
            <div className="flex-shrink-0 w-8 h-8 bg-blue-100 text-blue-600 rounded-full flex items-center justify-center font-bold">3</div>
            <div className="space-y-3 w-full">
              <h3 className="font-bold text-lg">Copie e Cole o Código</h3>
              <p className="text-gray-600">
                Selecione a opção <strong>Configuração</strong> (ou Config) na caixa que aparece. Você verá um código parecido com este abaixo. Copie os valores e substitua no arquivo <code>services/firebaseConfig.ts</code>.
              </p>
              
              <div className="bg-slate-900 text-slate-300 p-4 rounded-xl font-mono text-sm overflow-x-auto relative group">
                <pre>{`const firebaseConfig = {
  apiKey: "AIzaSyDOC...",
  authDomain: "seu-projeto.firebaseapp.com",
  projectId: "seu-projeto",
  storageBucket: "seu-projeto.appspot.com",
  messagingSenderId: "123456...",
  appId: "1:123456..."
};`}</pre>
                <div className="absolute top-2 right-2 opacity-50 text-xs">Exemplo</div>
              </div>
            </div>
          </div>

          <div className="bg-yellow-50 border border-yellow-200 p-4 rounded-xl flex items-start gap-3">
             <div className="mt-1 text-yellow-600"><LayoutTemplate className="w-5 h-5"/></div>
             <div>
               <h4 className="font-bold text-yellow-800 text-sm">Ainda não criou o banco de dados?</h4>
               <p className="text-yellow-700 text-sm mt-1">
                 Lembre-se de ir no menu <strong>Criação &gt; Firestore Database</strong> e clicar em "Criar banco de dados" no modo de teste, caso ainda não tenha feito.
               </p>
             </div>
          </div>

        </div>
      </div>
    </div>
  );
};
