import React, { useMemo } from 'react';
import { KeyTransaction, TransactionStatus } from '../types';
import { Clock, Key, CheckCircle, Box, User, Tag } from 'lucide-react';

interface TransactionListProps {
  transactions: KeyTransaction[];
  onReturn: (id: string) => void;
  filter: 'ALL' | 'ACTIVE';
}

export const TransactionList: React.FC<TransactionListProps> = ({ transactions, onReturn, filter }) => {
  
  const filteredData = useMemo(() => {
    if (filter === 'ACTIVE') {
      return transactions.filter(t => t.status === TransactionStatus.ACTIVE);
    }
    return transactions;
  }, [transactions, filter]);

  if (filteredData.length === 0) {
    return (
      <div className="flex flex-col items-center justify-center py-12 text-gray-400 bg-white rounded-xl shadow-sm border border-gray-100">
        <Key className="w-12 h-12 mb-3 opacity-20" />
        <p>Nenhum registro encontrado no SGC.</p>
      </div>
    );
  }

  return (
    <div className="space-y-4">
      {filteredData.map((t) => {
        // Define cores baseadas no status
        const isCompleted = t.status === TransactionStatus.COMPLETED;
        const borderClass = isCompleted ? 'border-gray-100 opacity-90' : 'border-blue-100';
        const bgClass = isCompleted ? 'bg-gray-50/50' : 'bg-white';

        return (
          <div 
            key={t.id} 
            className={`relative p-5 rounded-xl border transition-all hover:shadow-md ${bgClass} ${borderClass}`}
          >
            <div className="flex flex-col md:flex-row gap-4">
              
              {/* Left Icon (Letra da Chave) */}
              <div className="flex-shrink-0">
                <div className={`w-14 h-14 flex flex-col items-center justify-center rounded-xl font-bold border ${
                    !isCompleted 
                      ? 'bg-blue-100 text-blue-600 border-blue-200'
                      : 'bg-gray-100 text-gray-500 border-gray-200'
                  }`}>
                  <span className="text-xl leading-none">{t.keyLetter.replace('Lab', '')}</span>
                  {t.keyLetter.includes('Lab') && <span className="text-[10px] font-normal uppercase">Lab</span>}
                </div>
              </div>

              {/* Main Info */}
              <div className="flex-1 space-y-3">
                
                {/* Header: Lab Name */}
                <div className="flex flex-col sm:flex-row justify-between items-start gap-2">
                  <div>
                    <h3 className="text-lg font-bold text-gray-900 leading-tight">{t.labName}</h3>
                    <div className="flex items-center gap-2 mt-1 flex-wrap">
                      <div className="flex items-center text-sm text-gray-600 gap-1.5">
                        <User className="w-4 h-4 text-gray-400" />
                        <span className="font-medium">{t.personName}</span>
                      </div>
                      <span className="text-gray-300">|</span>
                      <div className="flex items-center text-xs text-gray-500 gap-1">
                        <Tag className="w-3 h-3" />
                        {t.reservationType === 'Reserva programada' ? 'Programada' : 'Emergencial'}
                      </div>
                    </div>
                  </div>
                </div>

                {/* Timestamps Info Line */}
                <div className="flex flex-wrap gap-3 text-sm pt-1">
                  <div className="flex items-center gap-1.5 text-gray-500">
                    <Clock className="w-3.5 h-3.5" />
                    <span>
                      Retirou: <span className="font-medium text-gray-700">{new Date(t.pickupTime).toLocaleString('pt-BR', { hour: '2-digit', minute: '2-digit' })}</span>
                    </span>
                  </div>
                  
                  {t.returnTime && (
                    <div className="flex items-center gap-1.5 text-emerald-600 font-medium">
                      <CheckCircle className="w-3.5 h-3.5" />
                      <span>
                        Devolveu: {new Date(t.returnTime).toLocaleString('pt-BR', { hour: '2-digit', minute: '2-digit' })}
                      </span>
                    </div>
                  )}
                </div>

                {/* Extras */}
                {t.additionalItems && t.additionalItems.length > 0 && !t.additionalItems.includes('Nenhum') && (
                  <div className="flex items-start gap-2 text-sm text-gray-600 bg-gray-50 p-2 rounded-md border border-gray-100 inline-block">
                    <Box className="w-3.5 h-3.5 mt-0.5 text-indigo-400" />
                    <span>Levou: <span className="font-medium text-gray-800">{t.additionalItems.join(', ')}</span></span>
                  </div>
                )}
              </div>

              {/* Action Button */}
              <div className="flex items-center justify-end sm:self-center">
                {t.status === TransactionStatus.ACTIVE ? (
                  <button
                    onClick={() => onReturn(t.id)}
                    className="flex items-center gap-2 px-5 py-2.5 bg-white border border-gray-200 text-gray-700 font-bold rounded-lg hover:bg-green-50 hover:text-green-700 hover:border-green-200 transition-all shadow-sm active:scale-95 group"
                  >
                    <CheckCircle className="w-4 h-4 text-gray-400 group-hover:text-green-600" />
                    Devolver
                  </button>
                ) : (
                  <span className="flex items-center gap-1.5 px-3 py-1 bg-gray-100 text-gray-400 text-sm font-medium rounded-full">
                    Encerrado
                  </span>
                )}
              </div>
            </div>
          </div>
        );
      })}
    </div>
  );
};