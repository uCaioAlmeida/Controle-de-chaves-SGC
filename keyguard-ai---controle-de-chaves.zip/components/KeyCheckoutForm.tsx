import React, { useState, useMemo, useEffect } from 'react';
import { KeyTransaction, KeyLetter, ReservationType, Reservation } from '../types';
import { LAB_OPTIONS, KEY_LETTERS, EXTRAS_OPTIONS } from '../data/labList';
import * as DataService from '../services/dataService';
import { User, MapPin, Check, Loader2, Sparkles, Clock, Calendar, UserCheck, Edit2, X, AlertCircle } from 'lucide-react';

interface KeyCheckoutFormProps {
  onSubmit: (data: Omit<KeyTransaction, 'id' | 'status' | 'pickupTime' | 'returnTime'>) => void;
  onCancel: () => void;
}

export const KeyCheckoutForm: React.FC<KeyCheckoutFormProps> = ({ onSubmit, onCancel }) => {
  const [personName, setPersonName] = useState('');
  const [labSearch, setLabSearch] = useState('');
  const [selectedLab, setSelectedLab] = useState('');
  const [keyLetter, setKeyLetter] = useState<KeyLetter | ''>('');
  const [reservationType, setReservationType] = useState<ReservationType | ''>('');
  const [extras, setExtras] = useState<string[]>([]);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [showLabDropdown, setShowLabDropdown] = useState(false);
  
  // Logic for Suggestions
  const [activeReservation, setActiveReservation] = useState<Reservation | null>(null);
  const [partialMatches, setPartialMatches] = useState<Reservation[]>([]);
  const [allSuggestions, setAllSuggestions] = useState<Reservation[]>([]);
  
  // Mode: 'SUGGESTED' (Using excel data) or 'MANUAL' (Typing)
  const [nameInputMode, setNameInputMode] = useState<'SUGGESTED' | 'MANUAL'>('MANUAL');

  useEffect(() => {
    const suggestions = DataService.getActiveReservationsNow();
    setAllSuggestions(suggestions);
  }, []);

  const filteredLabs = useMemo(() => {
    return LAB_OPTIONS.filter(lab => 
      lab.toLowerCase().includes(labSearch.toLowerCase())
    );
  }, [labSearch]);

  const displaySuggestions = useMemo(() => {
    if (selectedLab) return []; 
    if (!labSearch) return allSuggestions;
    
    const normalize = (s: string) => s.toLowerCase().normalize("NFD").replace(/[\u0300-\u036f]/g, "");
    const searchNorm = normalize(labSearch);
    
    return allSuggestions.filter(res => normalize(res.labName).includes(searchNorm));
  }, [allSuggestions, labSearch, selectedLab]);

  // Main Logic for Matching when Lab Selected
  useEffect(() => {
    if (selectedLab) {
      // 1. Try finding smart match (Time + Name)
      const exactMatch = DataService.findSmartReservation(selectedLab);
      
      if (exactMatch) {
         setActiveReservation(exactMatch);
         setPartialMatches([]);
         setPersonName(exactMatch.responsible);
         setNameInputMode('SUGGESTED');
         setReservationType('Reserva programada');
      } else {
         // 2. Fallback: Find any reservation for this lab TODAY, ignoring time
         const looseMatches = DataService.findReservationsForLabToday(selectedLab);
         
         if (looseMatches.length > 0) {
           // We found reservations for today, but the time didn't match logic.
           // Show them anyway as "Partial Matches" so user can select.
           setPartialMatches(looseMatches);
           setActiveReservation(null); 
           // Don't auto-fill name yet, let user click the card
         } else {
           setActiveReservation(null);
           setPartialMatches([]);
         }
         
         setNameInputMode('MANUAL');
         setPersonName('');
      }
    } else {
      setActiveReservation(null);
      setPartialMatches([]);
      setNameInputMode('MANUAL');
    }
  }, [selectedLab]);

  const toggleExtra = (item: string) => {
    if (item === 'Nenhum') {
      setExtras(['Nenhum']);
      return;
    }
    setExtras(prev => {
      const newExtras = prev.filter(e => e !== 'Nenhum');
      if (newExtras.includes(item)) return newExtras.filter(e => e !== item);
      return [...newExtras, item];
    });
  };

  const handleApplySuggestion = (res: Reservation) => {
    // Attempt map to official list
    const normalize = (s: string) => s.toLowerCase().normalize("NFD").replace(/[\u0300-\u036f]/g, "").replace(/[^a-z0-9]/g, "");
    const searchToken = normalize(res.labName.split(' ')[0]); 
    const matchLab = LAB_OPTIONS.find(l => normalize(l).includes(searchToken));
    const finalLabName = matchLab || res.labName;

    setSelectedLab(finalLabName);
    setLabSearch(finalLabName);
    setPersonName(res.responsible);
    setNameInputMode('SUGGESTED');
    setReservationType('Reserva programada');
    setActiveReservation(res);
    setShowLabDropdown(false);
  };

  const handleApplyPartialMatch = (res: Reservation) => {
      setPersonName(res.responsible);
      setNameInputMode('SUGGESTED');
      setReservationType('Reserva programada');
      setActiveReservation(res);
      setPartialMatches([]); // Hide list, show active
  }

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!personName || !selectedLab || !keyLetter || !reservationType || extras.length === 0) return;

    setIsSubmitting(true);
    setTimeout(() => {
      onSubmit({
        personName,
        labName: selectedLab,
        keyLetter: keyLetter as KeyLetter,
        reservationType: reservationType as ReservationType,
        additionalItems: extras,
        scheduledEndTime: activeReservation ? activeReservation.endTime : undefined
      });
      setIsSubmitting(false);
    }, 400);
  };

  const handleSelectLab = (lab: string) => {
    setSelectedLab(lab);
    setLabSearch(lab);
    setShowLabDropdown(false);
  };

  return (
    <div className="bg-white p-6 rounded-2xl shadow-xl border border-gray-100 max-h-[90vh] overflow-y-auto">
      <div className="mb-6 border-b border-gray-100 pb-4">
        <h2 className="text-xl font-bold text-gray-800">
          SGC - Retirada de Chave
        </h2>
        <p className="text-gray-500 text-sm mt-1">Preencha o formulário para registrar a entrega.</p>
      </div>

      {/* --- TOP SUGGESTIONS (GLOBAL) --- */}
      {displaySuggestions.length > 0 && !selectedLab && (
        <div className="mb-8 animate-fade-in">
          <h3 className="text-sm font-semibold text-gray-600 mb-3 flex items-center gap-2">
            <Sparkles className="w-4 h-4 text-indigo-500" />
            {labSearch ? 'Sugestões para sua busca' : 'Sugestões de Agora (Planilha)'}
          </h3>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            {displaySuggestions.map(res => (
              <button
                key={res.id}
                type="button"
                onClick={() => handleApplySuggestion(res)}
                className="text-left bg-indigo-50 hover:bg-indigo-100 border border-indigo-100 hover:border-indigo-300 p-3 rounded-lg transition-all group shadow-sm"
              >
                <div className="flex justify-between items-start mb-1">
                  <span className="font-bold text-indigo-900 text-sm line-clamp-1">{res.labName}</span>
                  <span className="text-[10px] bg-white px-1.5 py-0.5 rounded text-indigo-600 font-bold border border-indigo-100 whitespace-nowrap">
                    {res.startTime} - {res.endTime}
                  </span>
                </div>
                <div className="text-xs text-indigo-700 flex items-center gap-1">
                   <User className="w-3 h-3" /> {res.responsible}
                </div>
              </button>
            ))}
          </div>
        </div>
      )}

      <form onSubmit={handleSubmit} className="space-y-6">
        
        {/* 1. Sala / Laboratório */}
        <div className="relative z-20">
          <label className="block text-sm font-semibold text-gray-700 mb-1.5 flex items-center gap-2">
            <span className="bg-blue-100 text-blue-700 w-5 h-5 rounded-full flex items-center justify-center text-xs">1</span>
            Sala / Laboratório
          </label>
          <div className="relative">
            <MapPin className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
            <input
              type="text"
              required
              value={labSearch}
              onChange={(e) => {
                setLabSearch(e.target.value);
                setShowLabDropdown(true);
                if (e.target.value === '') setSelectedLab('');
              }}
              onFocus={() => setShowLabDropdown(true)}
              placeholder="Pesquise a sala ou laboratório..."
              className="w-full pl-10 pr-4 py-2.5 border border-gray-200 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 outline-none"
            />
             {selectedLab && (
              <button 
                type="button"
                onClick={() => {
                  setSelectedLab('');
                  setLabSearch('');
                  setActiveReservation(null);
                  setPersonName('');
                  setNameInputMode('MANUAL');
                  setPartialMatches([]);
                }}
                className="absolute right-3 top-1/2 -translate-y-1/2 p-1 bg-gray-100 hover:bg-gray-200 rounded-full text-gray-500"
              >
                <X className="w-3 h-3" />
              </button>
            )}
          </div>
          
          {showLabDropdown && (
            <div className="absolute z-50 w-full mt-1 bg-white border border-gray-200 rounded-lg shadow-lg max-h-60 overflow-y-auto">
              {filteredLabs.length > 0 ? (
                filteredLabs.map((lab) => (
                  <button
                    key={lab}
                    type="button"
                    onClick={() => handleSelectLab(lab)}
                    className="w-full text-left px-4 py-2 hover:bg-blue-50 text-sm text-gray-700 border-b border-gray-50 last:border-0"
                  >
                    {lab}
                  </button>
                ))
              ) : (
                <div className="px-4 py-3 text-sm text-gray-500">Nenhuma sala encontrada.</div>
              )}
            </div>
          )}
        </div>

        {/* --- PARTIAL MATCHES (FOUND BUT TIME MISMATCH) --- */}
        {partialMatches.length > 0 && !activeReservation && (
           <div className="bg-amber-50 border border-amber-200 rounded-lg p-3 animate-fade-in">
              <div className="flex items-start gap-2 mb-2">
                 <AlertCircle className="w-4 h-4 text-amber-600 mt-0.5" />
                 <div>
                    <h4 className="text-sm font-bold text-amber-900">Encontrei reservas para hoje</h4>
                    <p className="text-xs text-amber-700">O horário atual não bate exatamente com a planilha, mas você pode usar uma destas:</p>
                 </div>
              </div>
              <div className="grid gap-2">
                 {partialMatches.map(pm => (
                    <button
                       key={pm.id}
                       type="button"
                       onClick={() => handleApplyPartialMatch(pm)}
                       className="text-left bg-white border border-amber-200 p-2 rounded hover:bg-amber-100 transition-colors flex justify-between items-center"
                    >
                       <span className="text-sm font-medium text-gray-800">{pm.responsible}</span>
                       <span className="text-xs font-mono text-gray-500">{pm.startTime} - {pm.endTime}</span>
                    </button>
                 ))}
              </div>
           </div>
        )}

        {/* 2. Responsável (Smart Selector) */}
        <div>
          <label className="block text-sm font-semibold text-gray-700 mb-2 flex items-center gap-2">
            <span className="bg-blue-100 text-blue-700 w-5 h-5 rounded-full flex items-center justify-center text-xs">2</span>
            Responsável pela retirada
          </label>

          {activeReservation ? (
            <div className="space-y-2 animate-fade-in">
              {/* Option A: Suggested from Schedule */}
              <div 
                onClick={() => {
                   setNameInputMode('SUGGESTED');
                   setPersonName(activeReservation.responsible);
                }}
                className={`cursor-pointer p-3 rounded-xl border flex items-center justify-between transition-all ${
                   nameInputMode === 'SUGGESTED' 
                   ? 'bg-green-50 border-green-200 ring-1 ring-green-200' 
                   : 'bg-white border-gray-200 hover:border-gray-300'
                }`}
              >
                 <div className="flex items-center gap-3">
                    <div className={`w-8 h-8 rounded-full flex items-center justify-center ${nameInputMode === 'SUGGESTED' ? 'bg-green-100 text-green-600' : 'bg-gray-100 text-gray-400'}`}>
                       <UserCheck className="w-5 h-5" />
                    </div>
                    <div>
                       <p className={`text-sm font-bold ${nameInputMode === 'SUGGESTED' ? 'text-green-800' : 'text-gray-700'}`}>
                         {activeReservation.responsible}
                       </p>
                       <p className="text-xs text-gray-500 flex items-center gap-1">
                          <Clock className="w-3 h-3" /> 
                          Agendado: {activeReservation.startTime} - {activeReservation.endTime}
                       </p>
                    </div>
                 </div>
                 {nameInputMode === 'SUGGESTED' && <Check className="w-5 h-5 text-green-600" />}
              </div>

              {/* Option B: Manual Input */}
              <div 
                 onClick={() => {
                    if (nameInputMode !== 'MANUAL') {
                      setNameInputMode('MANUAL');
                      setPersonName(''); // Clear suggested name
                    }
                 }}
                 className={`cursor-pointer p-3 rounded-xl border transition-all ${
                    nameInputMode === 'MANUAL' 
                    ? 'bg-blue-50 border-blue-200 ring-1 ring-blue-200' 
                    : 'bg-white border-gray-200 hover:border-gray-300'
                 }`}
              >
                 <div className="flex items-center gap-3 w-full">
                    <div className={`flex-shrink-0 w-8 h-8 rounded-full flex items-center justify-center ${nameInputMode === 'MANUAL' ? 'bg-blue-100 text-blue-600' : 'bg-gray-100 text-gray-400'}`}>
                       <Edit2 className="w-4 h-4" />
                    </div>
                    
                    <div className="flex-1">
                       {nameInputMode === 'MANUAL' ? (
                          <input 
                            type="text"
                            value={personName}
                            onChange={(e) => setPersonName(e.target.value)}
                            placeholder="Digite o nome de quem está retirando..."
                            className="w-full bg-transparent border-none p-0 text-sm focus:ring-0 text-gray-800 font-medium placeholder:font-normal placeholder:text-gray-400"
                            autoFocus
                            onClick={(e) => e.stopPropagation()} 
                          />
                       ) : (
                          <p className="text-sm font-medium text-gray-600">Outra pessoa (Campo aberto)</p>
                       )}
                    </div>
                 </div>
              </div>
            </div>
          ) : (
            /* Fallback: Standard Input if no suggestion found */
            <div className="relative">
              <User className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
              <input
                type="text"
                required
                value={personName}
                onChange={(e) => setPersonName(e.target.value)}
                placeholder="Nome completo"
                className="w-full pl-10 pr-4 py-2.5 border border-gray-200 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 outline-none"
              />
            </div>
          )}
        </div>

        {/* 3. Letra da Chave */}
        <div>
          <label className="block text-sm font-semibold text-gray-700 mb-2 flex items-center gap-2">
            <span className="bg-blue-100 text-blue-700 w-5 h-5 rounded-full flex items-center justify-center text-xs">3</span>
            Qual letra da chave?
          </label>
          <div className="grid grid-cols-4 sm:grid-cols-4 gap-2">
            {KEY_LETTERS.map((option) => (
              <button
                key={option}
                type="button"
                onClick={() => setKeyLetter(option as KeyLetter)}
                className={`py-2 px-1 text-sm rounded-lg border transition-all ${
                  keyLetter === option
                    ? 'bg-blue-600 text-white border-blue-600 shadow-md'
                    : 'bg-white text-gray-600 border-gray-200 hover:border-blue-300 hover:bg-blue-50'
                }`}
              >
                {option}
              </button>
            ))}
          </div>
        </div>

        {/* 4. Tipo de Reserva */}
        <div>
          <label className="block text-sm font-semibold text-gray-700 mb-2 flex items-center gap-2">
            <span className="bg-blue-100 text-blue-700 w-5 h-5 rounded-full flex items-center justify-center text-xs">4</span>
            Tipo de reserva
          </label>
          <div className="flex flex-col gap-2">
            {['Reserva programada', 'Reserva extra / emergencial'].map((type) => (
              <label key={type} className={`flex items-center gap-3 p-3 rounded-lg border cursor-pointer transition-colors ${reservationType === type ? 'bg-blue-50 border-blue-200' : 'border-gray-200 hover:bg-gray-50'}`}>
                <input
                  type="radio"
                  name="reservationType"
                  value={type}
                  checked={reservationType === type}
                  onChange={(e) => setReservationType(e.target.value as ReservationType)}
                  className="w-4 h-4 text-blue-600 border-gray-300 focus:ring-blue-500"
                />
                <span className="text-sm font-medium text-gray-700">{type}</span>
              </label>
            ))}
          </div>
        </div>

        {/* 5. Extras */}
        <div>
          <label className="block text-sm font-semibold text-gray-700 mb-2 flex items-center gap-2">
            <span className="bg-blue-100 text-blue-700 w-5 h-5 rounded-full flex items-center justify-center text-xs">5</span>
            Extras
          </label>
          <div className="grid grid-cols-2 gap-2">
            {EXTRAS_OPTIONS.map((item) => (
              <label key={item} className={`flex items-center gap-2 p-2.5 rounded-lg border cursor-pointer transition-colors ${extras.includes(item) ? 'bg-indigo-50 border-indigo-200' : 'border-gray-200 hover:bg-gray-50'}`}>
                <input
                  type="checkbox"
                  checked={extras.includes(item)}
                  onChange={() => toggleExtra(item)}
                  className="w-4 h-4 text-indigo-600 rounded border-gray-300 focus:ring-indigo-500"
                />
                <span className="text-sm text-gray-700">{item}</span>
              </label>
            ))}
          </div>
        </div>

        {/* Actions */}
        <div className="flex gap-3 pt-4 border-t border-gray-100">
          <button
            type="button"
            onClick={onCancel}
            className="flex-1 px-4 py-2.5 border border-gray-300 text-gray-700 font-medium rounded-lg hover:bg-gray-50 transition-colors"
          >
            Cancelar
          </button>
          <button
            type="submit"
            disabled={isSubmitting}
            className="flex-1 px-4 py-2.5 bg-blue-600 text-white font-medium rounded-lg hover:bg-blue-700 transition-all shadow-md hover:shadow-lg disabled:opacity-70 disabled:cursor-not-allowed flex items-center justify-center gap-2"
          >
            {isSubmitting ? (
              <>
                <Loader2 className="w-5 h-5 animate-spin" />
                Salvando...
              </>
            ) : (
              'Confirmar'
            )}
          </button>
        </div>
      </form>
    </div>
  );
};