import { initializeApp } from 'firebase/app';
import { getFirestore } from 'firebase/firestore';

// Configuração do Firebase fornecida
const firebaseConfig = {
  apiKey: "AIzaSyCZWvE-aOvo4K3w5AdgwXaWUxg8f2m808Q",
  authDomain: "sgchaves-6e746.firebaseapp.com",
  projectId: "sgchaves-6e746",
  storageBucket: "sgchaves-6e746.firebasestorage.app",
  messagingSenderId: "763940575512",
  appId: "1:763940575512:web:72ffa165eda1272f9ca66d"
};

// Verifica se a configuração básica existe
const hasConfig = firebaseConfig.apiKey && firebaseConfig.projectId;

let app;
let db: any = null;

if (hasConfig) {
  try {
    app = initializeApp(firebaseConfig);
    db = getFirestore(app);
    console.log("Firebase conectado com sucesso.");
  } catch (error) {
    console.error("Erro ao inicializar Firebase:", error);
  }
}

export { db };
export const isConfigured = !!db;