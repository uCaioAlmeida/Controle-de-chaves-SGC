import { db } from './firebaseConfig';
import { 
  collection, 
  addDoc, 
  updateDoc, 
  doc, 
  onSnapshot, 
  query, 
  orderBy, 
  writeBatch,
  getDocs,
  where
} from 'firebase/firestore';
import { KeyTransaction, TransactionStatus, Reservation } from '../types';

// --- CONFIGURAÇÃO ---
const TRANS_COLLECTION = 'transactions';
const RES_COLLECTION = 'reservations';

// --- STATE LOCAL (CACHE) ---
// Mantemos uma cópia local atualizada em tempo real para buscas síncronas rápidas (fuzzy match)
let localReservationsCache: Reservation[] = [];
let localTransactionsCache: KeyTransaction[] = [];

// --- LISTENERS ---
// Inicializa os ouvintes do Firestore para manter o app sincronizado
export const subscribeToTransactions = (callback: (data: KeyTransaction[]) => void) => {
  if (!db) {
    console.warn("Firebase não configurado. Modo offline não suportado nesta versão.");
    return () => {};
  }

  // 1. Escuta Transações (Ordenadas por data de retirada decrescente)
  const q = query(collection(db, TRANS_COLLECTION), orderBy('pickupTime', 'desc'));
  
  const unsubscribeTrans = onSnapshot(q, (snapshot) => {
    const data = snapshot.docs.map(doc => ({
      id: doc.id,
      ...doc.data()
    })) as KeyTransaction[];
    
    localTransactionsCache = data;
    callback(data);
  }, (error) => {
    console.error("Erro ao ouvir transações:", error);
  });

  // 2. Escuta Reservas (Para popular o cache de sugestões)
  // Escutamos apenas reservas futuras ou de hoje para não pesar, mas por simplicidade pegaremos tudo
  // Idealmente, filtraríamos no Firestore por data >= hoje.
  const resCollection = collection(db, RES_COLLECTION);
  onSnapshot(resCollection, (snapshot) => {
    localReservationsCache = snapshot.docs.map(doc => ({
      id: doc.id,
      ...doc.data()
    })) as Reservation[];
  });

  return unsubscribeTrans;
};

// --- AÇÕES DE TRANSAÇÃO ---

export const saveTransaction = async (transaction: KeyTransaction): Promise<void> => {
  if (!db) return;
  
  // Remove ID temporário se existir
  const { id, ...data } = transaction;

  // Firestore não aceita valores 'undefined'. Removemos as chaves undefined.
  const cleanData = Object.entries(data).reduce((acc, [key, value]) => {
    if (value !== undefined) {
      acc[key] = value;
    }
    return acc;
  }, {} as Record<string, any>);
  
  try {
    await addDoc(collection(db, TRANS_COLLECTION), cleanData);
  } catch (e) {
    console.error("Erro ao salvar transação:", e);
    alert("Erro de conexão ao salvar: " + (e as Error).message);
  }
};

export const updateTransaction = async (id: string, updates: Partial<KeyTransaction>): Promise<void> => {
  if (!db) return;
  
  // Sanitiza updates também
  const cleanUpdates = Object.entries(updates).reduce((acc, [key, value]) => {
    if (value !== undefined) {
      acc[key] = value;
    }
    return acc;
  }, {} as Record<string, any>);
  
  try {
    const docRef = doc(db, TRANS_COLLECTION, id);
    await updateDoc(docRef, cleanUpdates);
  } catch (e) {
    console.error("Erro ao atualizar transação:", e);
  }
};

// --- AÇÕES DE RESERVAS ---

export const saveReservations = async (reservations: Reservation[]): Promise<void> => {
  if (!db) return;

  try {
    const batch = writeBatch(db);
    const collectionRef = collection(db, RES_COLLECTION);

    // Nota: O Firestore tem limite de 500 operações por batch. 
    // Para produção robusta, deveríamos dividir em chunks. 
    // Assumindo importações pequenas (<500 linhas) por enquanto.
    
    reservations.forEach(res => {
      // Cria referência de documento novo
      const docRef = doc(collectionRef); 
      const { id, ...data } = res; // Remove ID gerado no front, deixa o Firestore criar
      batch.set(docRef, data);
    });

    await batch.commit();
    console.log("Reservas importadas com sucesso via Batch.");
  } catch (e) {
    console.error("Erro ao salvar reservas:", e);
    alert("Erro ao salvar no banco de dados.");
  }
};

export const clearReservations = async (): Promise<void> => {
  if (!db) return;
  
  if(!confirm("Atenção: Esta ação deletará TODAS as reservas do banco de dados online para todos os usuários. Continuar?")) return;

  try {
    // Busca todas e deleta uma por uma (Batch seria melhor, mas delete query requer backend admin sdk geralmente)
    const snapshot = await getDocs(collection(db, RES_COLLECTION));
    const batch = writeBatch(db);
    
    let count = 0;
    snapshot.docs.forEach((doc) => {
      batch.delete(doc.ref);
      count++;
    });

    if (count > 0) {
      await batch.commit();
    }
  } catch (e) {
    console.error("Erro ao limpar reservas:", e);
  }
};

// --- LÓGICA DE BUSCA E FILTRO (USA O CACHE LOCAL SINCRONIZADO) ---

const timeToMinutes = (timeStr: string): number => {
  if (!timeStr || !timeStr.includes(':')) return 0;
  const [hours, minutes] = timeStr.split(':').map(Number);
  return hours * 60 + minutes;
};

// Fuzzy Match Robusto
const isFuzzyMatch = (str1: string, str2: string): boolean => {
  if (!str1 || !str2) return false;
  const normalize = (s: string) => s.toLowerCase().normalize("NFD").replace(/[\u0300-\u036f]/g, "").replace(/[^a-z0-9\s]/g, '');
  const tokens1 = normalize(str1).split(/\s+/).filter(t => t.length > 2);
  const tokens2 = normalize(str2).split(/\s+/).filter(t => t.length > 2);
  const ignored = ['lab', 'laboratorio', 'laboratório', 'sala', 'cim1', 'cim2', 'cim3', 'cim4', 'sesi', 'andar', 'bloco'];
  
  if (tokens1.length === 0 || tokens2.length === 0) {
      return normalize(str1).includes(normalize(str2)) || normalize(str2).includes(normalize(str1));
  }

  for (const t1 of tokens1) {
    if (ignored.includes(t1)) continue;
    if (tokens2.some(t2 => t2.includes(t1) || t1.includes(t2))) return true;
  }
  return false;
};

const getTodayStr = () => {
    const now = new Date();
    const year = now.getFullYear();
    const month = String(now.getMonth() + 1).padStart(2, '0');
    const day = String(now.getDate()).padStart(2, '0');
    return `${year}-${month}-${day}`;
};

// Busca reserva que bate Data + Hora + Nome (Com janela de tolerância)
export const findSmartReservation = (labName: string): Reservation | undefined => {
  const reservations = localReservationsCache; // Usa cache sincronizado
  const todayStr = getTodayStr();
  const now = new Date();
  const currentMinutes = now.getHours() * 60 + now.getMinutes();

  return reservations.find(r => {
    if (r.date !== todayStr) return false;

    const startMins = timeToMinutes(r.startTime);
    const endMins = timeToMinutes(r.endTime);
    
    // Janela de 90 minutos antes do início até o fim da aula
    if (currentMinutes < (startMins - 90) || currentMinutes > endMins) return false;

    return isFuzzyMatch(r.labName, labName);
  });
};

// Busca qualquer reserva para este laboratório hoje
export const findReservationsForLabToday = (labName: string): Reservation[] => {
  const reservations = localReservationsCache; // Usa cache sincronizado
  const todayStr = getTodayStr();

  return reservations.filter(r => {
    if (r.date !== todayStr) return false;
    return isFuzzyMatch(r.labName, labName);
  }).sort((a, b) => timeToMinutes(a.startTime) - timeToMinutes(b.startTime));
};

export const getActiveReservationsNow = (): Reservation[] => {
  const reservations = localReservationsCache; // Usa cache sincronizado
  const todayStr = getTodayStr();
  const now = new Date();
  const currentMinutes = now.getHours() * 60 + now.getMinutes();

  return reservations.filter(r => {
    if (r.date !== todayStr) return false;
    
    const startMins = timeToMinutes(r.startTime);
    const endMins = timeToMinutes(r.endTime);
    // Janela ampla para mostrar sugestões no topo
    const isActiveOrUpcoming = currentMinutes >= (startMins - 90) && currentMinutes <= endMins;

    return isActiveOrUpcoming;
  }).sort((a, b) => timeToMinutes(a.startTime) - timeToMinutes(b.startTime));
};