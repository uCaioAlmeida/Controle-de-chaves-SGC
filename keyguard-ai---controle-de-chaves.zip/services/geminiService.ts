import { GoogleGenAI } from "@google/genai";
import { KeyTransaction, TransactionStatus } from "../types";

const getClient = () => {
    // Ensuring API Key is pulled from environment at runtime
    const apiKey = process.env.API_KEY;
    if (!apiKey) {
        throw new Error("API Key not found");
    }
    return new GoogleGenAI({ apiKey });
};

export const generateDailyReport = async (transactions: KeyTransaction[]): Promise<string> => {
  try {
    const ai = getClient();
    
    const recentTransactions = transactions.slice(0, 40);

    const dataContext = JSON.stringify(recentTransactions.map(t => ({
      quem: t.personName,
      laboratorio: t.labName,
      chave_letra: t.keyLetter,
      tipo_reserva: t.reservationType,
      extras: t.additionalItems.join(', '),
      retirada: new Date(t.pickupTime).toLocaleString('pt-BR'),
      devolucao: t.returnTime ? new Date(t.returnTime).toLocaleString('pt-BR') : 'PENDENTE',
      status: t.status
    })));

    const prompt = `
      Você é o assistente virtual do SGC (Sistema de Gestão de Chaves) do SENAI CIMATEC.
      Analise os registros de movimentação de chaves abaixo.

      Gere um relatório em Markdown (pt-BR) com:
      1. **Resumo Operacional**: Quantas chaves ativas, total do dia.
      2. **Análise de Reservas**: Qual o tipo de reserva mais comum (Programada vs Emergencial)?
      3. **Uso de Recursos**: Quais laboratórios estão sendo mais utilizados? Os kits extras (piloto, controle) estão sendo devolvidos?
      4. **Alertas**: Destaque se houver chaves "Reserva Extra/Emergencial" em aberto por muito tempo.

      Dados:
      ${dataContext}
    `;

    const response = await ai.models.generateContent({
      model: "gemini-2.5-flash",
      contents: prompt,
      config: {
        thinkingConfig: { thinkingBudget: 0 }
      }
    });

    return response.text || "Relatório indisponível.";
  } catch (error) {
    console.error("Gemini API Error:", error);
    return "Erro ao conectar com a IA. Tente novamente mais tarde.";
  }
};
